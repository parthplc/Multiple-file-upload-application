from django.db import models
from django.template.defaultfilters import slugify

class Document(models.Model):
    title = models.CharField(max_length = 100)
    description = models.TextField()

    class Meta:
        db_table = 'document'

    def __str__(self):
        return self.title

    def get_pictures(self):
    	return self.pictures.all()
    	#return Picture.objects.filter()


class Images(models.Model):

    image = models.ImageField(upload_to = 'pictures/')
    post = models.ForeignKey(Document, related_name='pictures', on_delete=models.SET_NULL, null=True)

    class Meta:
        db_table = 'image'

