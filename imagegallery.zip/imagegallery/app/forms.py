from django import forms
from .models import Document,Images

from app.models import Document


class DocumentForm(forms.ModelForm):
    title = forms.CharField(max_length=128,label='Title')
    description = forms.CharField(max_length=500, label="Image Description.")
    class Meta:
        model = Document
        fields = ('title','description', )



class ImageForm(forms.ModelForm):
    image = forms.ImageField(label='Image')
    class Meta:
        model = Images
        fields = ('image', )